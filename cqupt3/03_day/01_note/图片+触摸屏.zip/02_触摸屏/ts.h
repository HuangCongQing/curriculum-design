#ifndef __TS_H__
#define __TS_H__

#include <stdio.h>
#include "tslib.h"
#include "ui.h"

int get_ts();
struct ts_sample ts_xy;

#endif